Richard Coffey
ECE 3520
C13383509

SDE2 ReadMe.txt


In this archive:

sde2.caml:
-All of the required predicates for this program, in chronological order according to the requirements.

sde2.log:
-A log file testing every single function with different inputs.

readme.txt
-table of contents and Pledge

Pledge:
On my honor I have neither given nor reeived aid on this exam:
Richard Coffey
    
