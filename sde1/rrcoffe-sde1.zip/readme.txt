﻿Richard Coffey
rrcoffe
ECE 352
SDE #1

Contents:

sde1.pro : Predicates File
sde1.log : Log of predicates tests

Pledge:
On my honor I hve neither given nor received aid on this exam:
SIGN: Richard Coffey


